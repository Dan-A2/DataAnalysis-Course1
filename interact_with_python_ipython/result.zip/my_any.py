# coding: utf-8
def my_any(x):
    for elemnt in x:
        if bool(x):
            return True
    return False
